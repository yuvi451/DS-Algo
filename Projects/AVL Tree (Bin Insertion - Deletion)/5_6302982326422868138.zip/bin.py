class Bin:
    def __init__(self, bin_id, capacity):
        pass

    def add_object(self, object):
        # Implement logic to add an object to this bin
        pass

    def remove_object(self, object_id):
        # Implement logic to remove an object by ID
        pass
